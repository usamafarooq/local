<?php
class Invoice_model extends MY_Model{

}